
# Declaración Oficial de Autoría – DonaPool

**Autor:** José Luis Moreno Roa  
**Correo de contacto:** jose01.moreno@gmail.com  
**Fecha de publicación:** 22 de abril de 2025

Este documento declara públicamente que el sistema DonaPool, su lógica, concepto y arquitectura técnica, son una creación original y están protegidos por derechos de autor. Queda prohibido su uso o implementación sin autorización expresa.

(Documento completo en formato PDF adjunto).
